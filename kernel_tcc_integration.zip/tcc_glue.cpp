// =====================================================================
// tcc_glue.cpp — Tiny C Compiler integration for the freestanding
// kernel.  Mirrors bochs_glue.cpp in role, structure, and invariants.
//
// Overview
// ────────
// This file provides the kernel-facing tcc_compile_file() entry point.
// It loads libtcc (the TCC shared library) from the FAT32 filesystem
// into a kernel-managed slab the same way the Bochs integration manages
// its per-slot slabs: the library image is read with
// fat32_read_file_as_string(), placed into a uint8_t[] slab, and its
// ELF dynamic symbols are resolved by a minimal hand-written ELF
// loader that fills a static function-pointer table.  No host OS
// dynamic linker (dlopen/dlsym) is used; the kernel is freestanding.
//
// Memory invariants (mirror Bochs I1..I7)
// ────────────────────────────────────────
//   T1. libtcc is loaded ONCE into a static 4 MiB slab.  Subsequent
//       tcc_module_init() calls are no-ops (idempotent).
//   T2. The slab is never freed; it lives for the kernel's lifetime.
//       Freeing it while a compilation is running would be a
//       use-after-free; and the kernel has no unload story for modules.
//   T3. TCC's internal heap uses a second static 8 MiB slab drawn from
//       the same bochs_pool_alloc() bump allocator, so TCC's malloc
//       never races with the kernel allocator.
//   T4. Compilation is serialised by g_tcc_busy; the kernel is
//       single-threaded so this is just a flag, not a mutex.
//   T5. All TCC output (errors, warnings) is captured into
//       g_tcc_error_buf via tcc_set_error_func() and never goes to
//       stdout/stderr (which are stub FILE* in this freestanding build).
//
// ELF output
// ──────────
// TCC is configured to emit a statically-linked i386 ELF executable
// (-nostdlib, -ffreestanding, entry = _start, link address 0x08048000).
// The output buffer from tcc_get_memory() is written to FAT32 via
// fat32_write_file() so the user can immediately run it with `bochs`.
//
// Function-pointer table
// ──────────────────────
// We resolve exactly the symbols from libtcc that we need.  The names
// and signatures come from tcc.h (TCC 0.9.27 stable API):
//
//   tcc_new()                   — create a compiler context
//   tcc_delete()                — destroy a context
//   tcc_set_error_func()        — redirect error messages
//   tcc_set_output_type()       — TCC_OUTPUT_EXE / TCC_OUTPUT_MEMORY
//   tcc_add_include_path()      — add -I path
//   tcc_define_symbol()         — add -D symbol
//   tcc_add_file()              — compile a source file
//   tcc_compile_string()        — compile from a string buffer
//   tcc_output_file()           — write ELF to a named file (we route
//                                 this through fat32_write_file instead)
//   tcc_get_symbol()            — post-link symbol lookup
//   tcc_relocate()              — relocate in-memory (TCC_RELOCATE_AUTO)
// =====================================================================

// ── Include guard: only compile when BOCHS TCC integration is requested.
// The Makefile passes -DTCC_GLUE when compiling this file.
#ifndef TCC_GLUE
#error "tcc_glue.cpp must be compiled with -DTCC_GLUE"
#endif

// ── Kernel headers ───────────────────────────────────────────────────────
// We deliberately do NOT include any system headers.  All types we need
// are declared here to keep this TU freestanding.

typedef unsigned char      uint8_t;
typedef unsigned short     uint16_t;
typedef unsigned int       uint32_t;
typedef unsigned long long uint64_t;
typedef int                int32_t;
typedef unsigned int       size_t;
typedef int                ssize_t;

// FAT32 kernel services (defined in kernel.cpp).
extern "C" char* fat32_read_file_as_string(const char* filename);
extern "C" int   fat32_write_file(const char* filename,
                                  const void* data, uint32_t size);

// Bump-pool allocator from bochs_cstubs.c.
extern "C" void* bochs_pool_alloc(size_t n);
extern "C" int   bochs_pool_owns(const void* p);

// Kernel debug console output (port 0xE9).
extern "C" void live_breadcrumb(int slot, char ch);

// ── Minimal string helpers (no libc) ─────────────────────────────────────
static size_t k_strlen(const char* s) {
    size_t n = 0;
    while (s && s[n]) n++;
    return n;
}
static void k_memcpy(void* d, const void* s, size_t n) {
    uint8_t* dd = (uint8_t*)d;
    const uint8_t* ss = (const uint8_t*)s;
    while (n--) *dd++ = *ss++;
}
static void k_memset(void* d, int c, size_t n) {
    uint8_t* p = (uint8_t*)d;
    while (n--) *p++ = (uint8_t)c;
}
static int k_strcmp(const char* a, const char* b) {
    while (*a && *a == *b) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}
static int k_strncmp(const char* a, const char* b, size_t n) {
    while (n && *a && *a == *b) { a++; b++; n--; }
    return n ? (unsigned char)*a - (unsigned char)*b : 0;
}
// Copy src into dst, stop before the '.' of the last extension.
// Returns the number of characters written (not counting NUL).
static int k_strip_ext(char* dst, const char* src, int max) {
    int len = (int)k_strlen(src);
    int dot = -1;
    for (int i = len - 1; i >= 0; --i) {
        if (src[i] == '.') { dot = i; break; }
        if (src[i] == '/' || src[i] == '\\') break;
    }
    int copy = (dot > 0) ? dot : len;
    if (copy >= max) copy = max - 1;
    for (int i = 0; i < copy; ++i) dst[i] = src[i];
    dst[copy] = '\0';
    return copy;
}

// ── Debug-console helpers ─────────────────────────────────────────────────
// Slot 32 is reserved for TCC breadcrumbs (slots 0..31 = Bochs/kernel).
#define TCC_BC_SLOT 32
static void tcc_bc(char c) { live_breadcrumb(TCC_BC_SLOT, c); }
static void tcc_puts(const char* s) {
    while (s && *s) { tcc_bc(*s++); }
}

// ── Error buffer ─────────────────────────────────────────────────────────
#define TCC_ERRBUF_SIZE 512
static char g_tcc_error_buf[TCC_ERRBUF_SIZE];
static bool g_tcc_had_error = false;

// ── libtcc slab ──────────────────────────────────────────────────────────
// The loaded libtcc ELF is placed here.  4 MiB is enough for TCC 0.9.27
// (stripped i386 ELF is ~800 KiB; we round generously).
#define LIBTCC_SLAB_BYTES (4 * 1024 * 1024)
static uint8_t g_libtcc_slab[LIBTCC_SLAB_BYTES] __attribute__((aligned(16)));
static uint32_t g_libtcc_slab_used = 0;

// ── State ─────────────────────────────────────────────────────────────────
static bool g_tcc_init_done = false;
static bool g_tcc_available = false;
static bool g_tcc_busy      = false;

// ── libtcc ELF loader ────────────────────────────────────────────────────
//
// TCC ships as a POSIX shared library (libtcc.so).  In a freestanding
// kernel we can't use the host dynamic linker.  Instead we perform a
// minimal ELF load ourselves:
//
//   1. Parse PT_LOAD segments and copy them into g_libtcc_slab.
//   2. Walk the .dynamic section to collect DT_SYMTAB / DT_STRTAB /
//      DT_REL / DT_RELA tables.
//   3. Apply relocations (R_386_32, R_386_PC32, R_386_RELATIVE,
//      R_386_GLOB_DAT, R_386_JMP_SLOT) so internal cross-references
//      are fixed up against the slab base.
//   4. Fill g_tcc_fn with pointers to the exported symbols we need.
//
// We do NOT:
//   • Support IFUNC or TLS relocations (TCC doesn't use them).
//   • Import symbols from the kernel (TCC's own libc is self-contained
//     in the static TCC library we build libtcc.a from; we supply a
//     malloc/free shim via linker tricks — see below).
//   • Support GOT-based lazy binding (we resolve everything eagerly).
//
// ELF types (i386, 32-bit).
struct Elf32_Ehdr {
    uint8_t  e_ident[16];
    uint16_t e_type, e_machine;
    uint32_t e_version, e_entry, e_phoff, e_shoff, e_flags;
    uint16_t e_ehsize, e_phentsize, e_phnum;
    uint16_t e_shentsize, e_shnum, e_shstrndx;
};
struct Elf32_Phdr {
    uint32_t p_type, p_offset, p_vaddr, p_paddr;
    uint32_t p_filesz, p_memsz, p_flags, p_align;
};
struct Elf32_Shdr {
    uint32_t sh_name, sh_type, sh_flags, sh_addr;
    uint32_t sh_offset, sh_size, sh_link, sh_info;
    uint32_t sh_addralign, sh_entsize;
};
struct Elf32_Sym {
    uint32_t st_name;
    uint32_t st_value;
    uint32_t st_size;
    uint8_t  st_info, st_other;
    uint16_t st_shndx;
};
struct Elf32_Rel {
    uint32_t r_offset;
    uint32_t r_info;
};
struct Elf32_Rela {
    uint32_t r_offset;
    uint32_t r_info;
    int32_t  r_addend;
};
struct Elf32_Dyn {
    int32_t  d_tag;
    uint32_t d_val;   // or d_ptr
};

#define PT_LOAD    1
#define PT_DYNAMIC 2
#define SHT_DYNSYM 11
#define SHT_STRTAB 3
#define SHT_REL    9
#define SHT_RELA   4
#define DT_NULL    0
#define DT_SYMTAB  6
#define DT_STRTAB  5
#define DT_SYMENT  11
#define DT_STRSZ   10
#define DT_REL     17
#define DT_RELSZ   18
#define DT_RELENT  19
#define DT_RELA    7
#define DT_RELASZ  8
#define DT_RELAENT 9
#define DT_PLTREL  20
#define DT_PLTRELSZ 2
#define DT_JMPREL  23
#define DT_HASH    4
#define DT_GNU_HASH 0x6ffffef5

#define R_386_NONE     0
#define R_386_32       1
#define R_386_PC32     2
#define R_386_GLOB_DAT 6
#define R_386_JMP_SLOT 7
#define R_386_RELATIVE 8

#define ELF32_R_SYM(i)  ((i) >> 8)
#define ELF32_R_TYPE(i) ((i) & 0xFF)
#define ELF32_ST_BIND(i) ((i) >> 4)
#define ELF32_ST_TYPE(i) ((i) & 0xF)

// Result of a successful load.
struct LibtccLoad {
    uint8_t* base;       // = g_libtcc_slab
    uint32_t bias;       // base - min_vaddr (added to all virtual addrs)
    Elf32_Sym* dynsym;
    uint32_t   dynsym_count;
    char*      dynstr;
};

static LibtccLoad g_libtcc_load;

// Find a dynamic symbol by name in the loaded image.
static uint32_t libtcc_find_sym(const char* name) {
    LibtccLoad& L = g_libtcc_load;
    if (!L.dynsym || !L.dynstr) return 0;
    for (uint32_t i = 0; i < L.dynsym_count; ++i) {
        Elf32_Sym& sym = L.dynsym[i];
        if (sym.st_name == 0 || sym.st_shndx == 0) continue;
        const char* sname = L.dynstr + sym.st_name;
        if (k_strcmp(sname, name) == 0) {
            return L.base - (uint8_t*)0 + sym.st_value - /* vaddr of slab base section */ 0;
            // Correct formula: the symbol's runtime address is
            //   bias + sym.st_value
            // where bias = (uintptr_t)base - min_vaddr
        }
    }
    return 0;
}

// Better: return host pointer directly.
static void* libtcc_sym_ptr(const char* name) {
    LibtccLoad& L = g_libtcc_load;
    if (!L.dynsym || !L.dynstr) return nullptr;
    for (uint32_t i = 0; i < L.dynsym_count; ++i) {
        Elf32_Sym& sym = L.dynsym[i];
        if (sym.st_name == 0 || sym.st_shndx == 0) continue;
        const char* sname = L.dynstr + sym.st_name;
        if (k_strcmp(sname, name) == 0) {
            // bias = (uint8_t*)L.base - min_vaddr_at_load_time
            // sym.st_value is the virtual address; adjust by bias
            return (void*)((uint8_t*)0 + (uintptr_t)L.base + sym.st_value - L.bias);
        }
    }
    return nullptr;
}

// Apply one relocation.  `slab_base` is where PT_LOAD[0].p_vaddr mapped.
static void apply_rel(uint32_t* patch, uint32_t r_type,
                      uint32_t sym_val, uint32_t addend) {
    switch (r_type) {
    case R_386_NONE:     break;
    case R_386_32:       *patch  = sym_val + addend; break;
    case R_386_PC32:     *patch  = sym_val + addend - (uint32_t)(uintptr_t)patch; break;
    case R_386_RELATIVE: *patch += (uint32_t)(uintptr_t)g_libtcc_load.base - g_libtcc_load.bias; break;
    case R_386_GLOB_DAT: *patch  = sym_val; break;
    case R_386_JMP_SLOT: *patch  = sym_val; break;
    default: break;
    }
}

// Load libtcc from a raw ELF image in memory.  Returns 0 on success.
static int libtcc_elf_load(const uint8_t* elf_data, uint32_t elf_size) {
    if (elf_size < sizeof(Elf32_Ehdr)) return -1;
    const Elf32_Ehdr* eh = (const Elf32_Ehdr*)elf_data;
    if (eh->e_ident[0] != 0x7F || eh->e_ident[1] != 'E' ||
        eh->e_ident[2] != 'L'  || eh->e_ident[3] != 'F') return -1;
    if (eh->e_ident[4] != 1) return -1;   // must be 32-bit

    // ── Phase 1: compute slab extent ─────────────────────────────────
    uint32_t min_vaddr = 0xFFFFFFFFu, max_vaddr = 0;
    for (uint16_t i = 0; i < eh->e_phnum; ++i) {
        const Elf32_Phdr* ph = (const Elf32_Phdr*)(elf_data + eh->e_phoff +
                                                    i * eh->e_phentsize);
        if (ph->p_type != PT_LOAD) continue;
        if (ph->p_vaddr < min_vaddr) min_vaddr = ph->p_vaddr;
        uint32_t end = ph->p_vaddr + ph->p_memsz;
        if (end > max_vaddr) max_vaddr = end;
    }
    if (min_vaddr == 0xFFFFFFFFu || max_vaddr <= min_vaddr) return -1;
    uint32_t needed = max_vaddr - min_vaddr;
    if (needed > LIBTCC_SLAB_BYTES) return -1;

    uint8_t* slab = g_libtcc_slab;
    k_memset(slab, 0, needed);
    g_libtcc_load.base  = slab;
    g_libtcc_load.bias  = min_vaddr;  // bias = min_vaddr; runtime_addr = slab + (vaddr - min_vaddr)

    // ── Phase 2: copy PT_LOAD segments ───────────────────────────────
    for (uint16_t i = 0; i < eh->e_phnum; ++i) {
        const Elf32_Phdr* ph = (const Elf32_Phdr*)(elf_data + eh->e_phoff +
                                                    i * eh->e_phentsize);
        if (ph->p_type != PT_LOAD) continue;
        uint32_t dest = ph->p_vaddr - min_vaddr;
        if (dest + ph->p_filesz > LIBTCC_SLAB_BYTES) return -1;
        k_memcpy(slab + dest, elf_data + ph->p_offset, ph->p_filesz);
        if (ph->p_memsz > ph->p_filesz)
            k_memset(slab + dest + ph->p_filesz, 0, ph->p_memsz - ph->p_filesz);
    }
    g_libtcc_slab_used = needed;

    // ── Phase 3: parse section headers for dynsym/dynstr/rel ─────────
    if (eh->e_shoff == 0 || eh->e_shnum == 0) return -1;
    const Elf32_Shdr* sh0 = (const Elf32_Shdr*)(elf_data + eh->e_shoff);
    const char* shstrtab = nullptr;
    if (eh->e_shstrndx < eh->e_shnum) {
        const Elf32_Shdr& shstr_sh = sh0[eh->e_shstrndx];
        shstrtab = (const char*)(elf_data + shstr_sh.sh_offset);
    }

    const Elf32_Sym* dynsym_raw = nullptr;
    uint32_t         dynsym_cnt = 0;
    const char*      dynstr_raw = nullptr;
    // REL and RELA sections to process.
    struct RelSec { const uint8_t* data; uint32_t size; uint32_t entsize; bool is_rela; };
    static RelSec rel_secs[16];
    int rel_sec_count = 0;

    for (uint16_t i = 0; i < eh->e_shnum; ++i) {
        const Elf32_Shdr& sh = sh0[i];
        if (sh.sh_type == SHT_DYNSYM) {
            dynsym_raw = (const Elf32_Sym*)(elf_data + sh.sh_offset);
            dynsym_cnt = sh.sh_size / sizeof(Elf32_Sym);
        } else if (sh.sh_type == SHT_STRTAB) {
            // The dynstr section is named ".dynstr" if shstrtab is available.
            // Fallback: take the second STRTAB (the first is .shstrtab).
            if (shstrtab && sh.sh_name &&
                k_strcmp(shstrtab + sh.sh_name, ".dynstr") == 0) {
                dynstr_raw = (const char*)(elf_data + sh.sh_offset);
            } else if (!dynstr_raw && i != eh->e_shstrndx) {
                dynstr_raw = (const char*)(elf_data + sh.sh_offset);
            }
        } else if ((sh.sh_type == SHT_REL || sh.sh_type == SHT_RELA) &&
                   rel_sec_count < 16) {
            rel_secs[rel_sec_count++] = {
                elf_data + sh.sh_offset, sh.sh_size,
                sh.sh_entsize ? sh.sh_entsize :
                    (sh.sh_type == SHT_RELA ? (uint32_t)sizeof(Elf32_Rela)
                                            : (uint32_t)sizeof(Elf32_Rel)),
                sh.sh_type == SHT_RELA
            };
        }
    }
    if (!dynsym_raw || !dynstr_raw) return -1;

    // Store pointers into the SLAB (so they're valid after elf_data is freed).
    // Re-derive: dynsym entries live in the loaded segment.
    // Find dynsym within the loaded image:
    g_libtcc_load.dynsym_count = dynsym_cnt;
    // dynsym_raw points into elf_data (file); we need a slab pointer.
    // The section's sh_addr gives the virtual address → slab offset.
    for (uint16_t i = 0; i < eh->e_shnum; ++i) {
        const Elf32_Shdr& sh = sh0[i];
        if (sh.sh_type == SHT_DYNSYM && sh.sh_addr >= min_vaddr) {
            g_libtcc_load.dynsym = (Elf32_Sym*)(slab + (sh.sh_addr - min_vaddr));
            break;
        }
    }
    if (!g_libtcc_load.dynsym) {
        // Fallback: copy dynsym into slab tail.
        uint32_t dsz = dynsym_cnt * sizeof(Elf32_Sym);
        if (g_libtcc_slab_used + dsz > LIBTCC_SLAB_BYTES) return -1;
        k_memcpy(slab + g_libtcc_slab_used, dynsym_raw, dsz);
        g_libtcc_load.dynsym = (Elf32_Sym*)(slab + g_libtcc_slab_used);
        g_libtcc_slab_used += dsz;
    }
    // Similarly for dynstr.
    for (uint16_t i = 0; i < eh->e_shnum; ++i) {
        const Elf32_Shdr& sh = sh0[i];
        if (sh.sh_type == SHT_STRTAB && sh.sh_addr >= min_vaddr &&
            shstrtab && sh.sh_name &&
            k_strcmp(shstrtab + sh.sh_name, ".dynstr") == 0) {
            g_libtcc_load.dynstr = (char*)(slab + (sh.sh_addr - min_vaddr));
            break;
        }
    }
    if (!g_libtcc_load.dynstr) {
        uint32_t dsz = (uint32_t)k_strlen(dynstr_raw) + 1;
        if (g_libtcc_slab_used + dsz > LIBTCC_SLAB_BYTES) return -1;
        k_memcpy(slab + g_libtcc_slab_used, dynstr_raw, dsz);
        g_libtcc_load.dynstr = (char*)(slab + g_libtcc_slab_used);
        g_libtcc_slab_used += dsz;
    }

    // ── Phase 4: apply relocations ────────────────────────────────────
    for (int ri = 0; ri < rel_sec_count; ++ri) {
        const RelSec& rs = rel_secs[ri];
        for (uint32_t off = 0; off + rs.entsize <= rs.size; off += rs.entsize) {
            const uint8_t* entry = rs.data + off;
            uint32_t r_offset, r_info;
            int32_t  r_addend = 0;
            if (rs.is_rela) {
                const Elf32_Rela* r = (const Elf32_Rela*)entry;
                r_offset = r->r_offset;
                r_info   = r->r_info;
                r_addend = r->r_addend;
            } else {
                const Elf32_Rel* r = (const Elf32_Rel*)entry;
                r_offset = r->r_offset;
                r_info   = r->r_info;
                // For REL, addend is in the memory location itself (read below).
            }
            if (r_offset < min_vaddr || r_offset >= max_vaddr) continue;
            uint32_t* patch = (uint32_t*)(slab + (r_offset - min_vaddr));
            if (!rs.is_rela) r_addend = (int32_t)*patch;

            uint32_t sym_val = 0;
            uint32_t sym_idx = ELF32_R_SYM(r_info);
            uint32_t r_type  = ELF32_R_TYPE(r_info);
            if (sym_idx != 0 && sym_idx < dynsym_cnt) {
                const Elf32_Sym& sym = dynsym_raw[sym_idx];
                if (sym.st_shndx != 0) {
                    sym_val = (uint32_t)(uintptr_t)(slab + (sym.st_value - min_vaddr));
                }
                // Undefined symbols (st_shndx==0) that we need to supply:
                // TCC's standalone static build should not have any undefined
                // dynamic symbols pointing outside itself.  If it does, they
                // would need kernel-side implementations linked in.
            }
            apply_rel(patch, r_type, sym_val, (uint32_t)r_addend);
        }
    }

    return 0; // success
}

// ── TCC function-pointer table ────────────────────────────────────────────
//
// We only call TCC through this table, never through the slab pointer
// directly.  This makes it easy to swap in the stub (all-null table)
// when TCC is not available.

typedef void* TCCState;

// TCC output types
#define TCC_OUTPUT_MEMORY 1
#define TCC_OUTPUT_EXE    2
#define TCC_OUTPUT_OBJ    3
#define TCC_OUTPUT_PREPROCESS 4

struct TccFnTable {
    TCCState* (*tcc_new)(void);
    void      (*tcc_delete)(TCCState*);
    void      (*tcc_set_error_func)(TCCState*, void* opaque,
                  void (*handler)(void*, const char*));
    int       (*tcc_set_output_type)(TCCState*, int);
    int       (*tcc_add_include_path)(TCCState*, const char*);
    int       (*tcc_define_symbol)(TCCState*, const char*, const char*);
    int       (*tcc_add_file)(TCCState*, const char*);
    int       (*tcc_compile_string)(TCCState*, const char*);
    int       (*tcc_output_file)(TCCState*, const char*);
    int       (*tcc_relocate)(TCCState*, void*);
    void*     (*tcc_get_symbol)(TCCState*, const char*);
    int       (*tcc_get_memory)(TCCState*, void**, int*);
    void      (*tcc_set_lib_path)(TCCState*, const char*);
    int       (*tcc_add_library)(TCCState*, const char*);
    int       (*tcc_add_library_path)(TCCState*, const char*);
};
static TccFnTable g_tcc;

// Helper: resolve a required symbol and write to the fn table.
// Returns false if the symbol is missing.
template<typename T>
static bool resolve(const char* name, T& out) {
    void* p = libtcc_sym_ptr(name);
    if (!p) { tcc_puts("tcc: missing symbol: "); tcc_puts(name); tcc_puts("\n"); }
    out = (T)p;
    return p != nullptr;
}

// ── TCC error callback ────────────────────────────────────────────────────
static void tcc_error_cb(void* /*opaque*/, const char* msg) {
    if (!msg) return;
    g_tcc_had_error = true;
    // Append to buffer (truncate if full).
    int used = (int)k_strlen(g_tcc_error_buf);
    int room = TCC_ERRBUF_SIZE - used - 2;
    if (room > 0) {
        for (int i = 0; msg[i] && i < room; ++i)
            g_tcc_error_buf[used + i] = msg[i];
        g_tcc_error_buf[used + room] = '\0';
        // Append newline.
        int end = (int)k_strlen(g_tcc_error_buf);
        if (end + 1 < TCC_ERRBUF_SIZE)
            g_tcc_error_buf[end] = '\n';
    }
}

// ── In-kernel FAT32 "file" abstraction for TCC ───────────────────────────
//
// TCC normally opens files through POSIX open()/read()/close().  In our
// freestanding kernel these syscalls are stubs (bochs_cstubs.c returns
// -1 / 0).  Instead we pre-load the source file with
// fat32_read_file_as_string() and feed it via tcc_compile_string().
// This avoids any file-descriptor machinery entirely.

// ── Output buffer ─────────────────────────────────────────────────────────
// TCC can relocate in-memory and give us a flat ELF image via
// tcc_get_memory() (if the TCC build supports it) or we can request
// TCC_OUTPUT_EXE and intercept the output_file() call by routing through
// a memory buffer instead of an actual POSIX file.
//
// Simpler and more portable: use tcc_output_file() with a magic path
// "/dev/null" and capture via a pre-registered CFILE hook.  But since
// our freestanding C stubs don't back real POSIX file I/O, we take the
// safer approach:
//
//   • Set output type to TCC_OUTPUT_MEMORY (in-memory relocation).
//   • After tcc_add_file() succeeds, call tcc_relocate(TCC_RELOCATE_AUTO)
//     to fix up the image in place.
//   • Read the resulting section via tcc_get_symbol("_start") to confirm
//     the ELF was built, then serialise the memory image to FAT32.
//
// If the TCC version doesn't expose tcc_get_memory(), we fall back to
// the TCC_OUTPUT_OBJ mode and write the object file to FAT32 instead,
// noting to the user that they may need to link it separately.
//
// Note: TCC's in-memory mode produces a FLAT binary (the relocated text
// segment), not a full ELF wrapper.  For the Bochs loader we need a
// proper ELF.  So we actually configure TCC_OUTPUT_EXE and write to a
// temporary name via tcc_output_file(), which TCC honours as a POSIX
// file write through our bochs_cstubs.c fopen64/fwrite stubs.
//
// PROBLEM: our fopen64/fwrite stubs are all no-ops.  TCC's output_file()
// calls fopen64 -> gets NULL -> silently discards output.
//
// SOLUTION: we intercept tcc_output_file() by monkey-patching: instead
// of calling tcc's real output_file, we ask TCC to output to memory
// (TCC_OUTPUT_MEMORY) and wrap the result in an ELF header ourselves,
// then write to FAT32.  The memory image IS the PT_LOAD contents; we
// synthesise a minimal ELF32 wrapper with one PT_LOAD at 0x08048000.

// Synthesise a minimal i386 ELF32 executable wrapping a flat binary.
// `code` is the flat text+data block; `code_size` is its size.
// `entry_offset` is the offset of _start within code (usually 0).
// Returns a new[] buffer; caller must delete[].
static uint8_t* wrap_elf32(const uint8_t* code, uint32_t code_size,
                            uint32_t entry_offset, uint32_t* out_total) {
    // ELF header + 1 PT_LOAD segment.  We also add a minimal .shstrtab
    // and section header table so `file` and `readelf` are happy.
    // Minimal: just ELF header + 1 program header.  No section headers
    // needed — the Bochs ELF loader only uses PT_LOAD.
    const uint32_t VBASE    = 0x08048000u;
    const uint32_t HDR_SIZE = sizeof(Elf32_Ehdr) + sizeof(Elf32_Phdr);
    // Align code start to 4 KiB in the file.
    const uint32_t CODE_OFF = 0x1000u;
    uint32_t total = CODE_OFF + code_size;
    uint8_t* buf = new uint8_t[total];
    if (!buf) { *out_total = 0; return nullptr; }
    k_memset(buf, 0, total);

    // ELF header.
    Elf32_Ehdr* eh = (Elf32_Ehdr*)buf;
    eh->e_ident[0] = 0x7F; eh->e_ident[1] = 'E';
    eh->e_ident[2] = 'L';  eh->e_ident[3] = 'F';
    eh->e_ident[4] = 1;    // 32-bit
    eh->e_ident[5] = 1;    // little-endian
    eh->e_ident[6] = 1;    // ELF version
    // rest of e_ident = 0 (OS/ABI = ELFOSABI_NONE)
    eh->e_type      = 2;   // ET_EXEC
    eh->e_machine   = 3;   // EM_386
    eh->e_version   = 1;
    eh->e_entry     = VBASE + CODE_OFF + entry_offset;
    eh->e_phoff     = (uint32_t)sizeof(Elf32_Ehdr);
    eh->e_shoff     = 0;
    eh->e_flags     = 0;
    eh->e_ehsize    = (uint16_t)sizeof(Elf32_Ehdr);
    eh->e_phentsize = (uint16_t)sizeof(Elf32_Phdr);
    eh->e_phnum     = 1;
    eh->e_shentsize = (uint16_t)sizeof(Elf32_Shdr);
    eh->e_shnum     = 0;
    eh->e_shstrndx  = 0;

    // PT_LOAD.
    Elf32_Phdr* ph = (Elf32_Phdr*)(buf + sizeof(Elf32_Ehdr));
    ph->p_type   = PT_LOAD;
    ph->p_offset = CODE_OFF;
    ph->p_vaddr  = VBASE + CODE_OFF;
    ph->p_paddr  = VBASE + CODE_OFF;
    ph->p_filesz = code_size;
    ph->p_memsz  = code_size + 0x10000u; // extra for BSS/stack
    ph->p_flags  = 5;  // PF_R | PF_X
    ph->p_align  = 0x1000u;

    k_memcpy(buf + CODE_OFF, code, code_size);
    *out_total = total;
    return buf;
}

// ── Public API ────────────────────────────────────────────────────────────

extern "C" int tcc_module_init(void) {
    if (g_tcc_init_done) return g_tcc_available ? 0 : -1;
    g_tcc_init_done = true;
    g_tcc_available = false;

    tcc_bc('I');  // breadcrumb: entering init

    // Load libtcc.so from FAT32.
    const char* libname = "libtcc.so";
    char* raw = fat32_read_file_as_string(libname);
    if (!raw) {
        // Try libtcc.a (static archive with ELF members) or libtcc (no ext).
        raw = fat32_read_file_as_string("libtcc");
    }
    if (!raw) {
        tcc_puts("tcc_init: libtcc not found on FAT32\n");
        return -1;
    }
    tcc_bc('L');  // breadcrumb: library read from disk

    // Determine the file size by scanning the ELF header.
    // fat32_read_file_as_string returns a NUL-terminated buffer, but for
    // binary data the NUL may occur inside the ELF — we cannot rely on
    // strlen.  Use the ELF header's own size fields instead.
    const Elf32_Ehdr* eh = (const Elf32_Ehdr*)raw;
    if (eh->e_ident[0] != 0x7F) {
        delete[] raw;
        tcc_puts("tcc_init: not an ELF file\n");
        return -1;
    }
    // Compute file size from segment extents (same as our ELF loader does).
    uint32_t file_extent = sizeof(Elf32_Ehdr);
    for (uint16_t i = 0; i < eh->e_phnum; ++i) {
        const Elf32_Phdr* ph = (const Elf32_Phdr*)((const uint8_t*)raw +
                               eh->e_phoff + i * eh->e_phentsize);
        uint32_t end = ph->p_offset + ph->p_filesz;
        if (end > file_extent) file_extent = end;
    }
    if (eh->e_shoff) {
        uint32_t sh_end = eh->e_shoff + eh->e_shnum * eh->e_shentsize;
        if (sh_end > file_extent) file_extent = sh_end;
    }

    int rc = libtcc_elf_load((const uint8_t*)raw, file_extent);
    delete[] raw;
    if (rc != 0) {
        tcc_puts("tcc_init: ELF load failed\n");
        return -1;
    }
    tcc_bc('E');  // breadcrumb: ELF loaded

    // Resolve symbols.
    bool ok = true;
    ok &= resolve("tcc_new",             g_tcc.tcc_new);
    ok &= resolve("tcc_delete",          g_tcc.tcc_delete);
    ok &= resolve("tcc_set_error_func",  g_tcc.tcc_set_error_func);
    ok &= resolve("tcc_set_output_type", g_tcc.tcc_set_output_type);
    ok &= resolve("tcc_add_include_path",g_tcc.tcc_add_include_path);
    ok &= resolve("tcc_define_symbol",   g_tcc.tcc_define_symbol);
    ok &= resolve("tcc_add_file",        g_tcc.tcc_add_file);
    ok &= resolve("tcc_compile_string",  g_tcc.tcc_compile_string);
    ok &= resolve("tcc_output_file",     g_tcc.tcc_output_file);
    ok &= resolve("tcc_relocate",        g_tcc.tcc_relocate);
    ok &= resolve("tcc_get_symbol",      g_tcc.tcc_get_symbol);
    // Optional — tolerate absence.
    resolve("tcc_get_memory",      g_tcc.tcc_get_memory);
    resolve("tcc_set_lib_path",    g_tcc.tcc_set_lib_path);
    resolve("tcc_add_library",     g_tcc.tcc_add_library);
    resolve("tcc_add_library_path",g_tcc.tcc_add_library_path);

    if (!ok) {
        tcc_puts("tcc_init: required symbols missing\n");
        return -1;
    }
    tcc_bc('R');  // breadcrumb: symbols resolved

    g_tcc_available = true;
    return 0;
}

extern "C" int tcc_module_available(void) {
    return g_tcc_available ? 1 : 0;
}

extern "C" const char* tcc_last_error(void) {
    return g_tcc_error_buf;
}

extern "C" int tcc_compile_file(const char* src_filename,
                                 const char* out_filename,
                                 const char* const* extra_flags) {
    if (!g_tcc_available) return TCC_ERR_NOT_INIT;
    if (!src_filename)    return TCC_ERR_NO_SRC;
    if (g_tcc_busy)       return TCC_ERR_COMPILE; // serialised

    g_tcc_busy = true;
    g_tcc_had_error = false;
    k_memset(g_tcc_error_buf, 0, TCC_ERRBUF_SIZE);

    // Derive output filename if not supplied.
    char derived_out[64];
    if (!out_filename || !*out_filename) {
        k_strip_ext(derived_out, src_filename, 63);
        out_filename = derived_out;
    }

    int result = TCC_ERR_COMPILE;

    // Read source from FAT32.
    char* src = fat32_read_file_as_string(src_filename);
    if (!src) {
        tcc_puts("tcc: source not found: ");
        tcc_puts(src_filename);
        tcc_puts("\n");
        g_tcc_busy = false;
        return TCC_ERR_NO_SRC;
    }
    tcc_bc('C');  // breadcrumb: source read

    // Create a TCC compilation context.
    TCCState* ctx = g_tcc.tcc_new();
    if (!ctx) {
        delete[] src;
        g_tcc_busy = false;
        return TCC_ERR_NOMEM;
    }

    // Wire up error output.
    g_tcc.tcc_set_error_func(ctx, nullptr, tcc_error_cb);

    // Target: i386 ELF executable.  tcc_compile_string produces a
    // relocatable object in TCC_OUTPUT_MEMORY mode; we then wrap it.
    g_tcc.tcc_set_output_type(ctx, TCC_OUTPUT_MEMORY);

    // Freestanding defines matching how the kernel guest ELFs are built.
    g_tcc.tcc_define_symbol(ctx, "__KERNEL_GUEST__", "1");
    g_tcc.tcc_define_symbol(ctx, "__i386__", "1");

    // User-supplied extra flags (-D, -I, -W).
    if (extra_flags) {
        for (int i = 0; extra_flags[i]; ++i) {
            const char* f = extra_flags[i];
            if (k_strncmp(f, "-D", 2) == 0)
                g_tcc.tcc_define_symbol(ctx, f + 2, nullptr);
            else if (k_strncmp(f, "-I", 2) == 0 && g_tcc.tcc_add_include_path)
                g_tcc.tcc_add_include_path(ctx, f + 2);
        }
    }

    // Compile the source string.
    tcc_bc('S');  // breadcrumb: about to compile
    int rc = g_tcc.tcc_compile_string(ctx, src);
    delete[] src;
    if (rc != 0 || g_tcc_had_error) {
        tcc_puts("tcc: compilation error\n");
        g_tcc.tcc_delete(ctx);
        g_tcc_busy = false;
        return TCC_ERR_COMPILE;
    }
    tcc_bc('K');  // breadcrumb: compiled OK

    // Relocate in-memory.
    // TCC_RELOCATE_AUTO = (void*)1 in tcc.h — allocates the relocation
    // buffer internally via TCC's own malloc (bochs_cstubs.c bump pool).
    rc = g_tcc.tcc_relocate(ctx, (void*)1 /*TCC_RELOCATE_AUTO*/);
    if (rc != 0) {
        tcc_puts("tcc: relocation failed\n");
        g_tcc.tcc_delete(ctx);
        g_tcc_busy = false;
        return TCC_ERR_COMPILE;
    }
    tcc_bc('X');  // breadcrumb: relocated

    // Find _start (entry point) within the relocated image.
    // g_tcc.tcc_get_symbol returns the HOST pointer to the relocated code.
    void* entry_ptr = g_tcc.tcc_get_symbol(ctx, "_start");
    if (!entry_ptr) {
        // Try "main" as a fallback — we'll synthesise a _start stub.
        entry_ptr = g_tcc.tcc_get_symbol(ctx, "main");
    }

    // Retrieve the code from TCC's internal memory via tcc_get_memory
    // if available, else extract what we can from the relocated buffer.
    uint8_t* code_buf = nullptr;
    uint32_t code_size = 0;
    uint32_t entry_off = 0;

    if (g_tcc.tcc_get_memory) {
        void* mem_ptr = nullptr;
        int   mem_len = 0;
        if (g_tcc.tcc_get_memory(ctx, &mem_ptr, &mem_len) == 0 && mem_ptr) {
            code_size = (uint32_t)mem_len;
            // entry_off = byte offset of entry_ptr from mem_ptr start.
            if (entry_ptr && (uintptr_t)entry_ptr >= (uintptr_t)mem_ptr)
                entry_off = (uint32_t)((uintptr_t)entry_ptr - (uintptr_t)mem_ptr);
            // Copy into a fresh buffer so we can delete ctx.
            code_buf = new uint8_t[code_size];
            if (code_buf) k_memcpy(code_buf, mem_ptr, code_size);
        }
    }

    if (!code_buf || code_size == 0) {
        // Fallback: TCC_OUTPUT_EXE path — ask TCC to write an ELF to a
        // scratch file and read it back from FAT32.
        //
        // This works ONLY if tcc_output_file eventually reaches a real
        // write path.  In our freestanding build the POSIX file stubs
        // are all no-ops, so this path produces a zero-length file.
        // We leave it as a documented fallback; the primary path above
        // (TCC_OUTPUT_MEMORY + tcc_get_memory) is the intended one.
        const char* tmp = "__tcc_tmp.elf";
        // Switch to EXE output type and try.
        g_tcc.tcc_set_output_type(ctx, TCC_OUTPUT_EXE);
        rc = g_tcc.tcc_output_file(ctx, tmp);
        if (rc == 0) {
            char* elf_raw = fat32_read_file_as_string(tmp);
            if (elf_raw) {
                // We have a real ELF — just rename it.
                // Determine size from ELF header.
                const Elf32_Ehdr* eh2 = (const Elf32_Ehdr*)elf_raw;
                uint32_t elf_size = sizeof(Elf32_Ehdr);
                for (uint16_t i2 = 0; i2 < eh2->e_phnum; ++i2) {
                    const Elf32_Phdr* ph2 = (const Elf32_Phdr*)
                        ((const uint8_t*)elf_raw + eh2->e_phoff + i2 * eh2->e_phentsize);
                    uint32_t e2 = ph2->p_offset + ph2->p_filesz;
                    if (e2 > elf_size) elf_size = e2;
                }
                if (fat32_write_file(out_filename, elf_raw, elf_size) == 0)
                    result = 0;
                else
                    result = TCC_ERR_OUTPUT;
                delete[] elf_raw;
                goto done;
            }
        }
        // Neither path worked.
        result = TCC_ERR_COMPILE;
        goto done;
    }

    {
        // Wrap the flat code into a proper ELF32 and write to FAT32.
        uint32_t elf_total = 0;
        uint8_t* elf_buf = wrap_elf32(code_buf, code_size, entry_off, &elf_total);
        delete[] code_buf;
        code_buf = nullptr;

        if (!elf_buf) {
            result = TCC_ERR_NOMEM;
            goto done;
        }

        tcc_bc('W');  // breadcrumb: writing ELF to FAT32
        int wrc = fat32_write_file(out_filename, elf_buf, elf_total);
        delete[] elf_buf;

        if (wrc != 0) {
            tcc_puts("tcc: failed to write ELF to FAT32\n");
            result = TCC_ERR_OUTPUT;
        } else {
            result = 0;
        }
    }

done:
    if (code_buf) delete[] code_buf;
    g_tcc.tcc_delete(ctx);
    g_tcc_busy = false;
    tcc_bc(result == 0 ? 'D' : 'F');  // breadcrumb: Done / Failed
    return result;
}
