/* ====================================================================
 * tcc_glue.h — freestanding TCC compiler integration for the kernel.
 *
 * Architecture mirrors the Bochs integration exactly:
 *
 *   tcc_glue.cpp   — real implementation, compiled with TCC=1.
 *                    Pulls in libtcc as a shared object loaded at
 *                    runtime from FAT32 into a kernel-managed slab,
 *                    then calls through its function-pointer table.
 *
 *   tcc_stub.cpp   — no-op fallback, compiled with TCC=0 (or when
 *                    libtcc.so is absent). Every function returns a
 *                    clear error code so the kernel can report
 *                    "TCC not available" instead of hanging.
 *
 * Usage from the kernel shell:
 *
 *   tcc <source.c>           — compile source.c → source (ELF i386)
 *   tcc <source.c> -o <out>  — compile with explicit output name
 *
 * The compiler always targets i386 ELF (same ABI as every other ELF
 * this kernel runs under Bochs).  The output file is written to
 * FAT32 so it can immediately be run with `bochs <out>`.
 * ==================================================================== */
#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ── One-shot initialisation ─────────────────────────────────────────────
 * Called once during kernel startup (or lazily on first `tcc` command).
 * In tcc_glue.cpp this loads libtcc into a kernel slab and resolves
 * every symbol we need.  In tcc_stub.cpp this is a no-op.
 * Returns 0 on success, negative on failure. */
int  tcc_module_init(void);

/* ── Compiler entry point ────────────────────────────────────────────────
 * Compile the C source file `src_filename` (read from FAT32) and write
 * the resulting i386 ELF to `out_filename` (written to FAT32).
 *
 * Parameters
 *   src_filename  — FAT32 filename of the C source (e.g. "hello.c")
 *   out_filename  — FAT32 filename for the ELF output (e.g. "hello")
 *                   May be NULL; the glue then derives it by stripping
 *                   the extension from src_filename.
 *   extra_flags   — NULL-terminated list of extra -D/-I/-W flags,
 *                   or NULL for none.  Passed verbatim to TCC.
 *
 * Returns 0 on success, negative errno-style on failure:
 *   TCC_ERR_NOT_INIT   (-1)  — tcc_module_init() not called / failed
 *   TCC_ERR_NO_SRC     (-2)  — source file not found on FAT32
 *   TCC_ERR_COMPILE    (-3)  — TCC reported a compilation error
 *   TCC_ERR_OUTPUT     (-4)  — could not write ELF to FAT32
 *   TCC_ERR_NOMEM      (-5)  — kernel allocator OOM
 */
int  tcc_compile_file(const char* src_filename,
                      const char* out_filename,
                      const char* const* extra_flags);

/* Error codes */
#define TCC_ERR_NOT_INIT  (-1)
#define TCC_ERR_NO_SRC    (-2)
#define TCC_ERR_COMPILE   (-3)
#define TCC_ERR_OUTPUT    (-4)
#define TCC_ERR_NOMEM     (-5)

/* ── Status query ────────────────────────────────────────────────────────
 * Returns non-zero if libtcc was successfully loaded and is ready. */
int  tcc_module_available(void);

/* ── Last error message ──────────────────────────────────────────────────
 * Returns a pointer to a static buffer holding the last TCC diagnostic
 * string (compiler error, linker error, etc.).  The buffer is
 * overwritten on every call to tcc_compile_file(). */
const char* tcc_last_error(void);

#ifdef __cplusplus
}
#endif
