/* test_module.h — interface between kernel.cpp and test_module.cpp
 *
 * The test module runs the Bochs CPU self-test sequence and reports
 * results back to the kernel via the TestSink callback table.
 * kernel.cpp owns the sink implementations; test_module.cpp owns the
 * test logic and calls back through the sink pointers.
 *
 * When building without the real Bochs test module, link
 * test_module_stub.cpp instead — every function is a harmless no-op.
 */
#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ── Callback table supplied by the kernel ───────────────────────────── */
typedef struct {
    /* Write one character cell to the 3-row VGA overlay buffer.       */
    void (*vga_cell)(int row, int col, char ch, uint8_t attr);
    /* Print a NUL-terminated line to the owning terminal window.      */
    void (*put_line)(const char* s);
    /* Repaint the screen mid-test (called after each phase completes). */
    void (*flush)(void);
} TestSink;

/* ── Result block filled in by test_module_run() ─────────────────────── */
typedef struct {
    int  phase1_ok;        /* non-zero if Bochs CPU init (phase 1) succeeded  */
    int  phase2_ticked;    /* number of CPU ticks executed in phase 2          */
    int  guest_exit_seen;  /* non-zero if the guest ELF exited cleanly         */
    int  guest_exit_code;  /* exit code reported by the guest via port 0xE8    */
    int  guest_out_len;    /* number of bytes captured from guest stdout       */
    char guest_out[512];   /* captured guest stdout (NUL-terminated)           */
} TestResult;

/* ── Public API ──────────────────────────────────────────────────────── */

/* Run the full Bochs self-test sequence (phases 1 + 2).
 * Blocks until the test completes or times out.
 * sink and res must not be NULL.                                        */
void test_module_run(TestSink* sink, TestResult* res);

/* Returns non-zero while test_module_run() is executing, so the fault
 * handler and breadcrumb writer know to route through the sink.         */
int  test_module_active(void);

/* Called by the fault handler when a CPU exception fires during a test. */
void test_module_fault(int vector, uint32_t eip);

/* Called by the Bochs guest-output path for each character the guest
 * writes to port 0xE9 (the Bochs debug port / stdout stub).            */
void test_module_breadcrumb(int slot, char ch);

/* Called by kernel_main after it has walked __init_array so the test
 * module's own guard doesn't walk it a second time.                    */
void test_module_mark_ctors_done(void);

/* Symbol defined in bochs_glue.cpp / bochs_stub.cpp — a 64-byte ring
 * buffer of single-byte progress markers written by the Bochs init
 * sequence.  Declared here so kernel.cpp's panic handler can dump it.  */
extern volatile unsigned char bx_panic_breadcrumbs[64];

#ifdef __cplusplus
}
#endif
