/* ufo.c — ported from ufo.cpp.
 * std::vector<std::string>/std::string/std::vector<char>/cin/cout are all
 * replaced with fixed-size char arrays and kio.h's kputs/kreadchar;
 * rand()/srand(time()) replaced with kio.h's keystroke-stirred krand()
 * (no timer port is available here to seed a real RNG from). */
#include "../kio.h"
#include "ufo_functions.h"

#define MAX_WORD 32
#define MAX_INCORRECT 26

int main(void)
{
    static const char *codeword_list[] = {
        "humans", "peace", "extraterrestrial", "aliens"
    };
    const int codeword_count = 4;

    const char *codeword;
    char answer[MAX_WORD];
    int wordlen;
    int i;

    int misses = 0;
    char incorrect[MAX_INCORRECT];
    int incorrect_count = 0;
    int guess;
    char letter;

    /* Game title */
    greet();

    /* Pick a random codeword */
    codeword = codeword_list[krand_range(codeword_count)];
    wordlen = kstrlen(codeword);

    /* Stores correctly guessed letters, with blanks for the rest */
    for (i = 0; i < wordlen; i++) {
        answer[i] = '_';
    }
    answer[wordlen] = '\0';

    /* Game loop */
    while (!kstreq(answer, codeword) && misses < 7) {

        /* Player's abduction status */
        display_misses(misses);
        display_status(incorrect, incorrect_count, answer);

        /* Get user input */
        kputs("Please enter your guess: ");
        letter = kreadchar();

        /* Search for that letter */
        guess = 0;
        for (i = 0; i < wordlen; i++) {
            if (letter == codeword[i]) {
                answer[i] = letter;
                guess = 1;
            }
        }

        /* Check if it has been found */
        if (guess) {
            kputs("Correct!\n");
        } else {
            kputs("Incorrect! The tractor beam pulls the person in further.\n");
            /* Add to the list of incorrect letters */
            if (incorrect_count < MAX_INCORRECT) {
                incorrect[incorrect_count++] = letter;
            }
            misses++;
        }
    }

    /* Game result */
    endgame(answer, codeword);

    kexit(0);
    return 0;
}
