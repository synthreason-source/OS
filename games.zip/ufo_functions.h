#ifndef UFO_FUNCTIONS_H
#define UFO_FUNCTIONS_H

/* Ported from ufo_functions.h: std::string/std::vector aren't available in
 * this freestanding guest, so guesses/answers are plain null-terminated
 * char buffers instead. */

void display_misses(int misses);

void greet(void);
void endgame(const char *answer, const char *codeword);
void display_status(const char *incorrect, int incorrect_count, const char *answer);

#endif /* UFO_FUNCTIONS_H */
