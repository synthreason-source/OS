/* TicTacToe.c — ported from TicTacToe.cpp: cout/cin replaced with
 * kputs/kputint/kreadint. Game logic is otherwise unchanged, including the
 * original's duplicate check of the (0,3,6) column, which is harmless
 * (it just re-checks a line already covered). */
#include "kio.h"

static char square[9] = {'0','1','2','3','4','5','6','7','8'};

static int checkwin(void)
{
    if (square[0] == square[1] && square[1] == square[2]) {
        return (square[0] == 'X') ? 1 : 2;
    } else if (square[3] == square[4] && square[4] == square[5]) {
        return (square[3] == 'X') ? 1 : 2;
    } else if (square[6] == square[7] && square[7] == square[8]) {
        return (square[6] == 'X') ? 1 : 2;
    } else if (square[0] == square[3] && square[3] == square[6]) {
        return (square[0] == 'X') ? 1 : 2;
    } else if (square[1] == square[4] && square[4] == square[7]) {
        return (square[1] == 'X') ? 1 : 2;
    } else if (square[2] == square[5] && square[5] == square[8]) {
        return (square[2] == 'X') ? 1 : 2;
    } else if (square[0] == square[4] && square[4] == square[8]) {
        return (square[0] == 'X') ? 1 : 2;
    } else if (square[2] == square[4] && square[4] == square[6]) {
        return (square[2] == 'X') ? 1 : 2;
    } else if (square[0] == square[3] && square[3] == square[6]) {
        return (square[0] == 'X') ? 1 : 2;
    } else {
        return 0;
    }
}

static void mark(int player, int box)
{
    if (player == 1) {
        square[box] = 'X';
    } else {
        square[box] = 'Y';
    }
}

static void display(void)
{
    int i;
    for (i = 0; i < 9; i++) {
        kputc(square[i]);
        kputc('\t');
        if (i == 2 || i == 5 || i == 8) {
            kputc('\n');
        }
    }
}

int main(void)
{
    int player1 = 1, player2 = 2;
    int box, result = 0, flag = 0;
    int i;

    display();

    for (i = 1; i < 5; i++) {

        kputs("\nPlayer  ");
        kputint(player1);
        kputs(", your turn ");
        box = kreadint();
        mark(player1, box);
        display();

        result = checkwin();
        if (result == 1) {
            kputs("\n Congratualtions! player ");
            kputint(player1);
            kputs(" has Won ");
            flag = 1;
            break;
        } else if (result == 2) {
            kputs("\n Congratualtions! player ");
            kputint(player2);
            kputs(" has Won ");
            flag = 1;
            break;
        }

        kputs("\n Player ");
        kputint(player2);
        kputs(", your turn ");
        box = kreadint();
        mark(player2, box);
        display();

        result = checkwin();
        if (result == 1) {
            kputs("\n Congratualtions! player ");
            kputint(player1);
            kputs(" has Won ");
            flag = 1;
            break;
        } else if (result == 2) {
            kputs("\n Congratualtions! player ");
            kputint(player2);
            kputs(" has Won ");
            flag = 1;
            break;
        }
    }

    if (flag == 0) {
        kputs(" \n Sorry, The game is a draw ");
    }

    kexit(0);
    return 0;
}
