/* 2048.c — ported from 2048.cpp.
 * The Tabuleiro class becomes a plain struct + free functions (no `new`/
 * heap available in a freestanding guest); std::setw(4) becomes
 * kputint_w(); cin.get()/system("clear") become kwaitkey()/kclear();
 * rand() becomes kio.h's keystroke-stirred krand_range() (no timer port
 * exists here to seed a real RNG from — see kio.h). */
#include "kio.h"

typedef struct {
    int pos[4][4];
} Tabuleiro;

static void tab_init(Tabuleiro *t)
{
    int i, j;
    for (i = 0; i < 4; i++)
        for (j = 0; j < 4; j++)
            t->pos[i][j] = 0;
}

static void tab_add(Tabuleiro *t)
{
    int x, y;
    do {
        x = krand_range(4);
        y = krand_range(4);
    } while (t->pos[x][y] != 0);
    t->pos[x][y] = 2;
}

static void tab_print(Tabuleiro *t)
{
    int i, j;
    for (i = 0; i < 4; i++) {
        for (j = 0; j < 4; j++) {
            kputint_w(t->pos[i][j], 4);
            kputc('|');
        }
        knewline();
    }
}

/* dir: 0 = up, 1 = down, 2 = left, 3 = right */
static void tab_move(Tabuleiro *t, int dir)
{
    int i, j, x;

    switch (dir) {
        case 0: /* up */
            for (i = 1; i < 4; i++) {
                for (j = 0; j < 4; j++) {
                    x = 1;
                    while (t->pos[i - x][j] == 0 && x < 4) {
                        t->pos[i - x][j] = t->pos[i - x + 1][j];
                        t->pos[i - x + 1][j] = 0;
                        x++;
                    }
                }
            }
            break;
        case 1: /* down */
            for (i = 3; i > 0; i--) {
                for (j = 0; j < 4; j++) {
                    x = 1;
                    while (t->pos[i + x][j] == 0 && x < 4) {
                        t->pos[i + x][j] = t->pos[i + x - 1][j];
                        t->pos[i + x - 1][j] = 0;
                        x++;
                    }
                }
            }
            break;
        case 2: /* left */
            for (j = 1; j < 4; j++) {
                for (i = 0; i < 4; i++) {
                    x = 1;
                    while (t->pos[i][j - x] == 0 && x < 4) {
                        t->pos[i][j - x] = t->pos[i][j - x + 1];
                        t->pos[i][j - x + 1] = 0;
                        x++;
                    }
                }
            }
            break;
        case 3: /* right */
            for (j = 3; j > 0; j--) {
                for (i = 0; i < 4; i++) {
                    x = 1;
                    while (t->pos[i][j + x] == 0 && x < 4) {
                        t->pos[i][j + x] = t->pos[i][j + x - 1];
                        t->pos[i][j + x - 1] = 0;
                        x++;
                    }
                }
            }
            break;
    }
}

int main(void)
{
    Tabuleiro a;

    tab_init(&a);
    tab_add(&a);
    tab_add(&a);
    tab_add(&a);
    tab_add(&a);
    tab_add(&a);
    tab_print(&a);

    kwaitkey();
    kclear();

    tab_move(&a, 3);
    tab_print(&a);

    kexit(0);
    return 0;
}
