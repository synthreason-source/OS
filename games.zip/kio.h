/* kio.h — small freestanding helper layer on top of bochs_drivers.h (DRIVERS.H)
 *
 * DRIVERS.H only gives us: outb/inb, kputc, kexit, kputs, getch.
 * These games were originally written against iostream/stdio/stdlib, none of
 * which exist in this bare-metal TCC guest. This header supplies just enough
 * of a replacement — line input, integer parsing/printing, tiny string
 * helpers and a PRNG — using nothing but the primitives above.
 *
 * There is no timer/RTC port exposed by DRIVERS.H, so there is no real
 * source of entropy for srand(time(NULL)). Instead krand() is a xorshift
 * generator that gets "stirred" with every keystroke the player types
 * (see kgetch()), so the sequence differs run to run based on what/when
 * the player types, instead of being identical every boot.
 */
#ifndef KIO_H
#define KIO_H

#include "DRIVERS.H"

/* ---------- tiny string helpers (no <string.h> available) ---------- */

static inline int kstrlen(const char *s)
{
    int n = 0;
    while (s[n]) n++;
    return n;
}

static inline int kstreq(const char *a, const char *b)
{
    while (*a && *b) {
        if (*a != *b) return 0;
        a++; b++;
    }
    return *a == *b;
}

static inline void kstrcpy(char *dst, const char *src)
{
    while ((*dst++ = *src++)) { }
}

/* ---------- screen helpers ---------- */

/* Clears the screen via an ANSI escape. If the console on the other end
 * of port 0xE9 isn't an ANSI terminal this is a harmless no-op sequence
 * of printable-ish bytes; there is no BIOS/VGA text-mode call available
 * here to do it any other way. */
static inline void kclear(void)
{
    kputs("\x1b[2J\x1b[H");
}

static inline void knewline(void)
{
    kputc('\n');
}

/* ---------- integer printing ---------- */

static inline void kputuint(unsigned int u)
{
    char buf[10];
    int i = 0;

    if (u == 0) {
        kputc('0');
        return;
    }
    while (u > 0) {
        buf[i++] = (char)('0' + (u % 10));
        u /= 10;
    }
    while (i > 0) {
        kputc(buf[--i]);
    }
}

static inline void kputint(int n)
{
    if (n < 0) {
        kputc('-');
        kputuint((unsigned int)(-n));
    } else {
        kputuint((unsigned int)n);
    }
}

/* prints n right-justified in a field of at least `width` characters,
 * (replacement for std::setw(width)) */
static inline void kputint_w(int n, int width)
{
    int v = n < 0 ? -n : n;
    int digits = 1;
    int pad;

    while (v >= 10) { v /= 10; digits++; }
    if (n < 0) digits++;

    pad = width - digits;
    while (pad-- > 0) kputc(' ');
    kputint(n);
}

/* ---------- PRNG (no hardware timer available, see file header) ---------- */

static unsigned long k_rand_state = 2463534242UL;

static inline void krand_stir(unsigned char b)
{
    k_rand_state ^= (unsigned long)b;
    k_rand_state ^= k_rand_state << 13;
    k_rand_state ^= k_rand_state >> 17;
    k_rand_state ^= k_rand_state << 5;
}

static inline unsigned long krand(void)
{
    k_rand_state ^= k_rand_state << 13;
    k_rand_state ^= k_rand_state >> 17;
    k_rand_state ^= k_rand_state << 5;
    return k_rand_state;
}

/* returns a value in [0, n) */
static inline int krand_range(int n)
{
    if (n <= 0) return 0;
    return (int)(krand() % (unsigned long)n);
}

/* ---------- keyboard input ---------- */

/* getch() that also feeds the PRNG some entropy from the keystroke */
static inline char kgetch(void)
{
    char c = getch();
    krand_stir((unsigned char)c);
    return c;
}

/* Reads one line (terminated by Enter) into buf, up to maxlen-1 chars,
 * null-terminated. Handles backspace. Echoes what's typed since this is
 * a raw keyboard port with no line-discipline of its own. Returns the
 * number of characters read. */
static inline int kreadline(char *buf, int maxlen)
{
    int len = 0;
    char c;

    for (;;) {
        c = kgetch();
        if (c == '\r' || c == '\n') {
            kputc('\n');
            break;
        }
        if (c == 0x08 || c == 0x7f) { /* backspace / DEL */
            if (len > 0) {
                len--;
                kputc(0x08);
                kputc(' ');
                kputc(0x08);
            }
            continue;
        }
        if (len < maxlen - 1) {
            buf[len++] = c;
            kputc(c);
        }
    }
    buf[len] = '\0';
    return len;
}

static inline int katoi(const char *s)
{
    int neg = 0;
    int val = 0;

    if (*s == '-') { neg = 1; s++; }
    while (*s >= '0' && *s <= '9') {
        val = val * 10 + (*s - '0');
        s++;
    }
    return neg ? -val : val;
}

/* replacement for `cin >> intVariable` */
static inline int kreadint(void)
{
    char buf[16];
    kreadline(buf, sizeof(buf));
    return katoi(buf);
}

/* replacement for `cin >> singleChar` (skips leading spaces/newlines) */
static inline char kreadchar(void)
{
    char c;
    do {
        c = kgetch();
    } while (c == ' ' || c == '\t' || c == '\r' || c == '\n');
    kputc(c);
    kputc('\n');
    return c;
}

/* waits for any single keystroke, discarding it — replacement for
 * cin.get() / system("PAUSE") */
static inline void kwaitkey(void)
{
    (void)kgetch();
}

#endif /* KIO_H */
