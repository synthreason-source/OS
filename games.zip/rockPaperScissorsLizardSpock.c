/*
This program prompts the user to select either Rock, Paper, Scissors, Lizard
or Spock. The computer randomly selects one too. Then it compares the
choices and reports the winner.

Ported from rockPaperScissorsLizardSpock.cpp: std::string/cin/cout replaced
with C string literals + kputs; rand()/srand(time()) replaced with kio.h's
keystroke-stirred krand() (no timer port is available, see kio.h).
*/
#include "kio.h"

int main(void)
{
    int computer = krand_range(5) + 1; /* 1..5 */
    int user = 0;
    const char *result = "";
    const char *rule = "";

    kputs("=================================\n");
    kputs("rock paper scissors Lizard Spock!\n");
    kputs("=================================\n");

    kputs("1) rock\n");
    kputs("2) paper\n");
    kputs("3) scissors\n");
    kputs("4) lizard\n");
    kputs("5) spock\n");
    user = kreadint();

    if (user == 1) {
        /*   ROCK   */
        if (computer == 1) { result = "Tie!"; rule = "Same choice"; }
        else if (computer == 2) { result = "Lose!"; rule = "paper covers rock"; }
        else if (computer == 3) { result = "Win!"; rule = "rock crushes scissors"; }
        else if (computer == 4) { result = "Win!"; rule = "rock crushes lizard"; }
        else if (computer == 5) { result = "Lose!"; rule = "Spock vaporises rock"; }

    } else if (user == 2) {
        /*   PAPER   */
        if (computer == 1) { result = "Win!"; rule = "paper covers rock"; }
        else if (computer == 2) { result = "Tie!"; rule = "Same choice"; }
        else if (computer == 3) { result = "Lose!"; rule = "scissors cut paper"; }
        else if (computer == 4) { result = "Lose!"; rule = "lizard eats paper"; }
        else if (computer == 5) { result = "Win!"; rule = "paper disproves Spock"; }

    } else if (user == 3) {
        /*   SCISSORS   */
        if (computer == 1) { result = "Lose!"; rule = "rock crushes scissors"; }
        else if (computer == 2) { result = "Win!"; rule = "scissors cut paper"; }
        else if (computer == 3) { result = "Tie!"; rule = "Same choice"; }
        else if (computer == 4) { result = "Win!"; rule = "scissors decapotates lizard"; }
        else if (computer == 5) { result = "Lose!"; rule = "Spock smashes scissors"; }

    } else if (user == 4) {
        /*   LIZARD   */
        if (computer == 1) { result = "Lose!"; rule = "rock crushes lizard"; }
        else if (computer == 2) { result = "Win!"; rule = "lizard eats paper"; }
        else if (computer == 3) { result = "Lose!"; rule = "scissors decapotates lizard"; }
        else if (computer == 4) { result = "Tie!"; rule = "Same choice"; }
        else if (computer == 5) { result = "Win!"; rule = "lizard poisens Spock"; }

    } else if (user == 5) {
        /*   SPOCK   */
        if (computer == 1) { result = "Win!"; rule = "Spock vaporises rock"; }
        else if (computer == 2) { result = "Lose!"; rule = "paper disproves Spock"; }
        else if (computer == 3) { result = "Win!"; rule = "Spock smashes scissors"; }
        else if (computer == 4) { result = "Lose!"; rule = "lizard poisens Spock"; }
        else if (computer == 5) { result = "Tie!"; rule = "Same choice"; }
    }

    kputs(result);
    kputs("\n");
    kputs(rule);
    kputs(".\n");

    kexit(0);
    return 0;
}
