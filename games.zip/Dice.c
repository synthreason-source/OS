/* Dice.c — ported from Dice.cpp to plain C for the bochs/TCC guest ABI.
 * cout/cin replaced with kputs/kputint/kreadint; rand()/srand(time()) has
 * no hardware timer here, so we use kio.h's keystroke-stirred krand(). */
#include "kio.h"

enum Status { CONTINUE, WON, LOST };

static int Roll(void)
{
    int die1 = 1 + krand_range(6);
    int die2 = 1 + krand_range(6);
    int workSum = die1 + die2;

    kputs("Player rolled ");
    kputint(die1);
    kputs(" + ");
    kputint(die2);
    kputs(" = ");
    kputint(workSum);
    knewline();

    return workSum;
}

static void play(void)
{
    int sum;
    int myPoint = 0;
    int rollCount = 0;
    enum Status gameStatus;

    sum = Roll();
    rollCount++;

    switch (sum) {
        case 7:
        case 11:
            gameStatus = WON;
            break;
        case 2:
        case 3:
        case 12:
            gameStatus = LOST;
            break;
        default:
            gameStatus = CONTINUE;
            myPoint = sum;
            kputs("Point is ");
            kputint(myPoint);
            knewline();
            break;
    }

    while (gameStatus == CONTINUE) {
        sum = Roll();
        rollCount++;

        if (sum == myPoint) {
            gameStatus = WON;
        } else if (sum == 7) {
            gameStatus = LOST;
        }
    }

    if (gameStatus == WON) {
        kputs("Player wins\n\n");
    } else {
        kputs("Player loses\n\n");
    }
}

int main(void)
{
    int choice;

    do {
        kputs("Choose an option\n");
        kputs("1. Play the game\n");
        kputs("2. Quit\n");
        choice = kreadint();
        if (choice == 1) {
            play();
        }
    } while (choice != 2);

    kexit(0);
    return 0;
}
