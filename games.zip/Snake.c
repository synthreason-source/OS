/* Snake.c — ported from Snake.cpp.
 *
 * The original relied on several things unavailable in this bare-metal
 * guest and had to be redesigned, not just re-pointed at new I/O calls:
 *
 *   - windows.h's GetKeyState() did non-blocking "is this key held down
 *     right now" polling, driven by a real-time Sleep(delay) tick.
 *     DRIVERS.H's getch() is *blocking* (it spins until a keystroke
 *     arrives) and there's no timer port to drive a real-time loop.
 *     So the game becomes turn-based: each call to loop() blocks for one
 *     keystroke (w/a/s/d changes heading, anything else keeps going the
 *     same way, 'q' quits) and the snake advances one cell per keystroke.
 *   - `new`/`delete`/std::vector-style heap allocation isn't available,
 *     so the board and the snake's tail buffer are fixed-size static
 *     arrays (MAXDIM / MAXDIM*MAXDIM) instead of heap-allocated ones.
 *   - system("cls") -> kclear(); system("PAUSE") -> kwaitkey().
 *   - Fixed an out-of-bounds bug in the original's checkDie(): it used
 *     `pos.x > width` (and same for y), but valid indices only go up to
 *     width-1/height-1, so pos.x == width slipped through and indexed
 *     one cell past the array. Changed the comparisons to >=.
 */
#include "kio.h"

#define MAXDIM 20
#define MAXTAIL (MAXDIM * MAXDIM)

typedef struct {
    int x, y;
} Vetor;

typedef struct {
    Vetor pos;
    Vetor speed;
    Vetor cauda[MAXTAIL];
    unsigned tam;
} Snake;

typedef struct {
    Vetor pos;
} Food;

static int pix[MAXDIM][MAXDIM];
static int lp = 1;
static unsigned height = MAXDIM;
static unsigned width = MAXDIM;

static Snake snk;
static Food fd;

static void rstpix(void)
{
    unsigned i, j;
    for (i = 0; i < height; i++)
        for (j = 0; j < width; j++)
            pix[i][j] = 0;
}

static void snake_init(Snake *s)
{
    s->pos.x = (int)(width / 2);
    s->pos.y = (int)(height / 2);
    s->speed.x = 0;
    s->speed.y = 0;
    s->tam = 1;
}

static void food_new(Food *f)
{
    f->pos.x = krand_range((int)width);
    f->pos.y = krand_range((int)height);
}

static void snake_setmov(Snake *s, int x, int y)
{
    s->speed.x = x;
    s->speed.y = y;
}

static void snake_die(Snake *s)
{
    s->pos.x = (int)(width / 2);
    s->pos.y = (int)(height / 2);
    s->tam = 1;

    kputs("PERDEU SEU INUTIL\n");
    kwaitkey();
}

static void snake_checkDie(Snake *s)
{
    unsigned i;

    if (s->pos.x < 0 || s->pos.x >= (int)width ||
        s->pos.y < 0 || s->pos.y >= (int)height) {
        snake_die(s);
        return;
    }

    for (i = 3; i < s->tam; i++) {
        if (s->pos.x == s->cauda[i].x && s->pos.y == s->cauda[i].y) {
            snake_die(s);
            return;
        }
    }
}

static void snake_update(Snake *s)
{
    unsigned i;

    s->pos.x += s->speed.x;
    s->pos.y += s->speed.y;

    snake_checkDie(s);

    s->cauda[s->tam].x = s->pos.x;
    s->cauda[s->tam].y = s->pos.y;

    for (i = 0; i < s->tam; i++) {
        s->cauda[i].x = s->cauda[i + 1].x;
        s->cauda[i].y = s->cauda[i + 1].y;
    }
}

static void snake_checkFood(Snake *s, Food *f)
{
    if (s->pos.x == f->pos.x && s->pos.y == f->pos.y) {
        food_new(f);
        if (s->tam + 1 < MAXTAIL) {
            s->tam++;
        }
    }
}

static void snake_draw(Snake *s)
{
    unsigned i;
    if (s->pos.x >= 0 && s->pos.x < (int)width &&
        s->pos.y >= 0 && s->pos.y < (int)height) {
        pix[s->pos.x][s->pos.y] = 1;
    }
    for (i = 0; i < s->tam; i++) {
        pix[s->cauda[i].x][s->cauda[i].y] = 1;
    }
}

static void food_draw(Food *f)
{
    pix[f->pos.x][f->pos.y] = 1;
}

static void draw(void)
{
    unsigned i, j;
    for (i = 0; i < height; i++) {
        for (j = 0; j < width; j++) {
            if (pix[j][i]) {
                kputs("[]");
            } else {
                kputs("  ");
            }
        }
        kputs("|\n");
    }
    for (i = 0; i < width; i++) {
        kputs("==");
    }
    knewline();
}

/* Blocks for one keystroke and turns it into a heading change (or keeps
 * the current heading). Returns 0 to keep playing, 1 to quit. */
static int loop(void)
{
    char c = kgetch();

    if (c == 'q' || c == 'Q') {
        return 1;
    } else if ((c == 'a' || c == 'A') && snk.speed.x != 1) {
        snake_setmov(&snk, -1, 0);
    } else if ((c == 'd' || c == 'D') && snk.speed.x != -1) {
        snake_setmov(&snk, 1, 0);
    } else if ((c == 'w' || c == 'W') && snk.speed.y != 1) {
        snake_setmov(&snk, 0, -1);
    } else if ((c == 's' || c == 'S') && snk.speed.y != -1) {
        snake_setmov(&snk, 0, 1);
    }
    /* any other key: keep moving the same direction */

    food_draw(&fd);
    snake_update(&snk);
    snake_checkDie(&snk);
    snake_checkFood(&snk, &fd);
    snake_draw(&snk);

    return 0;
}

static void setup(void)
{
    snake_init(&snk);
    food_new(&fd);
    width = height = MAXDIM;
}

int main(void)
{
    setup();
    kputs("Snake: w/a/s/d to steer, q to quit.\n");
    kwaitkey();

    while (lp) {
        rstpix();
        if (loop()) {
            lp = 0;
            break;
        }
        kclear();
        draw();
    }

    kexit(0);
    return 0;
}
