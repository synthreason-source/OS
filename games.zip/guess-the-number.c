/* guess-the-number.c — ported from guess-the-number.cpp.
 * printf/scanf replaced with kputs/kputint/kreadint; rand()/srand(time())
 * replaced with kio.h's keystroke-stirred krand() (see kio.h header comment
 * for why: there's no timer port in DRIVERS.H to seed from). */
#include "kio.h"

int main(void)
{
    int nombreMystere = krand_range(100) + 1; /* 1..100 */
    int guess;
    int cpt1 = 0;

    do {
        kputs("quel est le nombre mystere? : ");
        guess = kreadint();
        if (guess < nombreMystere) {
            kputs("c'est plus !\n");
        } else if (guess > nombreMystere) {
            kputs("c'est moins !\n");
        }
        cpt1++;
    } while (guess != nombreMystere);

    kputs("Bravo, vous avez trouve le nombre mystere en ");
    kputint(cpt1);
    kputs(" tentatives !!!\n");

    kwaitkey();
    kexit(0);
    return 0;
}
