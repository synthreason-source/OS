/* ufo_functions.c — ported from ufo_functions.cpp.
 * std::cout replaced with kputs/kputc; std::vector<char>/std::string
 * replaced with a plain char array + count, and a null-terminated char
 * buffer, respectively. The original had `else if (misses == 3)` twice in
 * a row (the second one dead code); the duplicate is dropped here. */
#include "../kio.h"
#include "ufo_functions.h"

void display_status(const char *incorrect, int incorrect_count, const char *answer)
{
    int i;

    /* Print list of incorrect letters */
    kputs("Incorrect Guesses: ");
    for (i = 0; i < incorrect_count; i++) {
        kputc(incorrect[i]);
        kputc(' ');
    }

    /* Print player's current answer */
    kputs("\nCodeword: ");
    for (i = 0; answer[i] != '\0'; i++) {
        kputc(answer[i]);
        kputc(' ');
    }
    kputc('\n');
}

void greet(void)
{
    kputs("=============\n");
    kputs("UFO: The Game\n");
    kputs("=============\n");
    kputs("Instructions: save your friend from alien abduction by guessing the letters in the codeword.\n");
}

void endgame(const char *answer, const char *codeword)
{
    if (kstreq(answer, codeword)) {
        /* Player has won */
        kputs("Hooray! You saved the person and earned a medal of honor!\n");
    } else {
        /* Player has lost */
        kputs("Oh no! The UFO just flew away with another person!\n");
    }

    kputs("The codeword was ");
    kputs(codeword);
    kputs(".\n");
}

void display_misses(int misses)
{
    if (misses == 0 || misses == 1) {
        kputs("                 .                            \n");
        kputs("                 |                            \n");
        kputs("              .-\"^\"-.                       \n");
        kputs("             /_....._\\                       \n");
        kputs("         .-\"`         `\"-.                  \n");
        kputs("        (  ooo  ooo  ooo  )                   \n");
        kputs("         '-.,_________,.-'    ,-----------.   \n");
        kputs("              /     \\        (  Send help! ) \n");
        kputs("             /   0   \\      / `-----------'  \n");
        kputs("            /  --|--  \\    /                 \n");
        kputs("           /     |     \\                     \n");
        kputs("          /     / \\     \\                   \n");
        kputs("         /               \\                   \n");

    } else if (misses == 2) {
        kputs("                 .                            \n");
        kputs("                 |                            \n");
        kputs("              .-\"^\"-.                       \n");
        kputs("             /_....._\\                       \n");
        kputs("         .-\"`         `\"-.                  \n");
        kputs("        (  ooo  ooo  ooo  )                   \n");
        kputs("         '-.,_________,.-'    ,-----------.   \n");
        kputs("              /  0  \\        (  Send help! ) \n");
        kputs("             / --|-- \\      / `-----------'  \n");
        kputs("            /    |    \\    /                 \n");
        kputs("           /    / \\    \\                    \n");
        kputs("          /             \\                    \n");
        kputs("         /               \\                   \n");

    } else if (misses == 3) {
        kputs("                 .                            \n");
        kputs("                 |                            \n");
        kputs("              .-\"^\"-.                       \n");
        kputs("             /_....._\\                       \n");
        kputs("         .-\"`         `\"-.                  \n");
        kputs("        (  ooo  ooo  ooo  )                   \n");
        kputs("         '-.,_________,.-'    ,-----------.   \n");
        kputs("              /--|--\\        (  Send help! ) \n");
        kputs("             /   |   \\      / `-----------'  \n");
        kputs("            /   / \\   \\    /                \n");
        kputs("           /           \\                     \n");
        kputs("          /             \\                    \n");
        kputs("         /               \\                   \n");

    } else if (misses == 4) {
        kputs("                 .                            \n");
        kputs("                 |                            \n");
        kputs("              .-\"^\"-.                       \n");
        kputs("             /_....._\\                       \n");
        kputs("         .-\"`         `\"-.                  \n");
        kputs("        (  ooo  ooo  ooo  )                   \n");
        kputs("         '-.,_________,.-'    ,-----------.   \n");
        kputs("              /  |  \\        (  Send help! ) \n");
        kputs("             /  / \\  \\      / `-----------' \n");
        kputs("            /         \\    /                 \n");
        kputs("           /           \\                     \n");
        kputs("          /             \\                    \n");
        kputs("         /               \\                   \n");

    } else if (misses == 5) {
        kputs("                 .                            \n");
        kputs("                 |                            \n");
        kputs("              .-\"^\"-.                       \n");
        kputs("             /_....._\\                       \n");
        kputs("         .-\"`         `\"-.                  \n");
        kputs("        (  ooo  ooo  ooo  )                   \n");
        kputs("         '-.,_________,.-'    ,-----------.   \n");
        kputs("              / / \\ \\        (  Send help! )\n");
        kputs("             /       \\      / `-----------'  \n");
        kputs("            /         \\    /                 \n");
        kputs("           /           \\                     \n");
        kputs("          /             \\                    \n");
        kputs("         /               \\                   \n");

    } else if (misses == 6) {
        kputs("                 .                            \n");
        kputs("                 |                            \n");
        kputs("              .-\"^\"-.                       \n");
        kputs("             /_....._\\                       \n");
        kputs("         .-\"`         `\"-.                  \n");
        kputs("        (  ooo  ooo  ooo  )                   \n");
        kputs("         '-.,_________,.-'    ,-----------.   \n");
        kputs("              /     \\        (  Send help! ) \n");
        kputs("             /       \\      / `-----------'  \n");
        kputs("            /         \\    /                 \n");
        kputs("           /           \\                     \n");
        kputs("          /             \\                    \n");
        kputs("         /               \\                   \n");
    }
}
