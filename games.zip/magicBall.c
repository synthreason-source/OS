/* magicBall.c — ported from magicBall.cpp.
 * std::string/cin/cout replaced with a fixed buffer + kreadline/kputs;
 * rand()/srand(time()) replaced with kio.h's krand_range (see kio.h). */
#include "kio.h"

static const char *answers[20] = {
    "It is certain.\n",
    "It is decidedly so.\n",
    "Without a doubt.\n",
    "Yes - definitely.\n",
    "You may rely on it.\n",
    "As I see it, yes.\n",
    "Most likely.\n",
    "Outlook good.\n",
    "Yes.\n",
    "Signs point to yes.\n",
    "Reply hazy, try again.\n",
    "Ask again later.\n",
    "Better not tell you now.\n",
    "Cannot predict now.\n",
    "Concentrate and ask again.\n",
    "Don't count on it.\n",
    "My reply is no.\n",
    "My sources say no.\n",
    "Outlook not so good.\n",
    "Very doubtful.\n"
};

int main(void)
{
    char question[128];

    kputs("Ask a question to the MAGIC \xf0\x9f\x8e\xb1 : ");
    kreadline(question, sizeof(question));

    kputs("MAGIC \xf0\x9f\x8e\xb1 SAYS: ");

    kputs(answers[krand_range(20)]);

    kexit(0);
    return 0;
}
